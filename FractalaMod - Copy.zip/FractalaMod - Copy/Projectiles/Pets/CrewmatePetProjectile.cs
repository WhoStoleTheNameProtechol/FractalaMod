﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Projectiles.Pets
{
    public class CrewmatePetProjectile : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            Main.projFrames[projectile.type] = 11;
            Main.projPet[projectile.type] = true;
        }
        public override void SetDefaults()
        {
            projectile.CloneDefaults(ProjectileID.MiniMinotaur);
            aiType = ProjectileID.MiniMinotaur;
        }
        public override bool PreAI()
        {
            Player player = Main.player[projectile.owner];
            player.petFlagDD2Gato = false;
            return true;
        }

        public override void AI()
        {
            Player player = Main.player[projectile.owner];
            FractalaModPlayer modPlayer = player.GetModPlayer<FractalaModPlayer>();
            if (player.dead)
            {
                modPlayer.CrewmatePet = false;
            }
            if (modPlayer.CrewmatePet)
            {
                projectile.timeLeft = 2;
            }
        }
    }
}

