﻿
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Projectiles
{
    public class OutbackBoomerangProjectile : ModProjectile
    {
        public override void SetDefaults()
        {
            projectile.width = 38;
            projectile.height = 38;
            projectile.friendly = true;
            projectile.magic = true;
            projectile.penetrate = 1;
            projectile.timeLeft = 600;
            projectile.light = 0;
            aiType = ProjectileID.WoodenBoomerang;


        }

        public override void AI()
        {
            projectile.velocity.Y += projectile.ai[1];
            if (Main.rand.NextBool(3))
            {
    
            }
        }

        public override bool OnTileCollide(Vector2 oldVelocity)
        {
            projectile.penetrate--;
            projectile.Kill();
            return false;
        }

        public override void Kill(int timeLeft)
        {
            for (int k = 0; k < 5; k++)
            {
         
            }
            Main.PlaySound(SoundID.Item10, projectile.position);
        }

       // public override void OnHitNPC(NPC target, int damage, float knockback, bool crit)
        
            //target.AddBuff(BuffID.OnFire, 5 * 60);
            //projectile.ai[0] += 0.1f;
            //projectile.velocity *= 0.75f;
        }
    }
