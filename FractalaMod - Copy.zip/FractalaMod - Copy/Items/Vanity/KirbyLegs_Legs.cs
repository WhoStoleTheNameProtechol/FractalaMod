using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Items.Vanity
{
	[AutoloadEquip(EquipType.Legs)]
	public class KirbyLegs : ModItem
	{
		public override void SetDefaults() {
			item.width = 18;
			item.height = 18;
			item.rare = ItemRarityID.Blue;
			item.vanity = true;
		}

		public override bool DrawLegs() {
			return false;
		}
	}
}