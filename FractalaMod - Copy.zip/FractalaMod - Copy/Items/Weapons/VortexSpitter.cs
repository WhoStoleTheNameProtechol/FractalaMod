﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Items.Weapons
{
	public class VortexSpitter : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Vortex Spitter");
			Tooltip.SetDefault("");
		}
		public override void SetDefaults()
		{
			item.damage = 249;
			item.ranged = true;
			item.width = 52;
			item.height = 24;
			item.useTime = 3;
			item.useAnimation = 3;
			item.useStyle = ItemUseStyleID.HoldingOut;
			item.noMelee = true;
			item.knockBack = 0;
			item.value = 23000;
			item.rare = ItemRarityID.Red;
			item.UseSound = SoundID.Item34;
			item.autoReuse = true;
			item.shoot = ProjectileID.Flames;
			item.shootSpeed = 18f;
			item.useAmmo = ItemID.Gel;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-22, 0);
		}
		public override void ModifyTooltips(List<TooltipLine> list)
		{
			foreach (TooltipLine line2 in list)
			{
				if (line2.mod == "Terraria" && line2.Name == "ItemName")
				{
					line2.overrideColor = new Color(230, 204, 128);
				}
			}
		}public override bool ConsumeAmmo(Player player)
		{
			return Main.rand.NextFloat() >= .82f;
		}
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			Vector2 muzzleOffset = Vector2.Normalize(new Vector2(speedX, speedY)) * 25f;
			if (Collision.CanHit(position, -22, 0, position + muzzleOffset, 0, 0))
			{
				position += muzzleOffset;
			}
			return true;
		}
	}
		}
	



