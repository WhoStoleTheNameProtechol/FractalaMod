﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using static Terraria.ModLoader.ModContent;
using Microsoft.Xna.Framework;
using FractalaMod.Projectiles;

namespace FractalaMod.Items.Weapons
{
    public class BloodyStream : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("Soko kara...");
            ItemID.Sets.Yoyo[item.type] = true;
            ItemID.Sets.GamepadExtraRange[item.type] = 15;
            ItemID.Sets.GamepadSmartQuickReach[item.type] = true;
        }

        public override void SetDefaults()
        {
            item.Size = new Vector2(24);
            item.rare = ItemRarityID.Green;
            item.value = Item.sellPrice(silver: 25);

            item.useTime = 25;
            item.useAnimation = 25;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.UseSound = SoundID.Item1;

            item.melee = true;
            item.channel = true;
            item.noMelee = true;
            item.noUseGraphic = true;

            item.damage = 22;
            item.knockBack = 3.5f;
            item.shoot = ProjectileType<Projectiles.Weapons.BloodyStreamProjectile>();
            item.shootSpeed = 16.5f;
        }

    }
}