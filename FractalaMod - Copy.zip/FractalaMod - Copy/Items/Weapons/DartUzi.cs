﻿using System;
using FractalaMod.Projectiles; 
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
    public class DartUzi : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("This thing spews dart at the speed of sound");

        }

        public override void SetDefaults()
        {
            item.CloneDefaults(ItemID.DartPistol);
            item.damage = 21;
            item.ranged = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 7;
            item.useAnimation = 7;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1;
            item.value = 10000;
            item.rare = ItemRarityID.LightRed;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.useAmmo = AmmoID.Dart;
            item.shootSpeed = 7f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.PoisonDart, 4);
            recipe.AddIngredient(ItemID.SoulofNight, 8);
            recipe.AddRecipeGroup(RecipeGroupID.IronBar, 8);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}