﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Items.Weapons
{
	public class HallowedFlamastic : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hallowed Flamastic");
			Tooltip.SetDefault("Uses Gel for ammo");
		}
		public override void SetDefaults()
		{
			item.damage = 86;
			item.ranged = true;
			item.width = 52;
			item.height = 24;
			item.useTime = 9;
			item.useAnimation = 9;
			item.useStyle = ItemUseStyleID.HoldingOut;
			item.noMelee = true;
			item.knockBack = 0;
			item.value = 25000;
			item.rare = ItemRarityID.LightRed;
			item.UseSound = SoundID.Item34;
			item.autoReuse = true;
			item.shoot = ProjectileID.Flames;
			item.shootSpeed = 12f;
			item.useAmmo = ItemID.Gel;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-22, 0);
		}
		public override void ModifyTooltips(List<TooltipLine> list)
		{
			foreach (TooltipLine line2 in list)
			{
				if (line2.mod == "Terraria" && line2.Name == "ItemName")
				{
					line2.overrideColor = new Color(230, 204, 128);
				}
			}
		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.HallowedBar, 20);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this, 100);
			recipe.AddRecipe();
		}
	}
}


