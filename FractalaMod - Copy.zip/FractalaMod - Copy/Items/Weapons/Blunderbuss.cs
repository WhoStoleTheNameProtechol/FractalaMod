﻿using System;
using FractalaMod.Projectiles; 
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
    public class Blunderbuss : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blunderbuss");
            Tooltip.SetDefault("Da da da da da da da da da da da  doo");

        }

        public override void SetDefaults()
        {
            item.damage = 70;
            item.ranged = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 60;
            item.useAnimation = 60;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1;
            item.value = 10000;
            item.rare = ItemRarityID.Orange;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shootSpeed = 7f;
            item.shoot = ProjectileType<Projectiles.Blunderball>();

        }
        public override void AddRecipes()
        {
        }
    }
}