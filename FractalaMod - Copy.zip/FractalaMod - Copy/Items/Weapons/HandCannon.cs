﻿using System;
using FractalaMod.Projectiles; 
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
    public class HandCannon : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("HandCannon");
            Tooltip.SetDefault("Blood is good for the bones..");

        }

        public override void SetDefaults()
        {
            item.damage = 28;
            item.ranged = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 40;
            item.useAnimation = 40;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1;
            item.value = 10000;
            item.rare = ItemRarityID.Green;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shootSpeed = 7f;
            item.shoot = ProjectileType<Projectiles.SkeletronHand>();

        }
        public override void AddRecipes()
        {
        }
    }
}