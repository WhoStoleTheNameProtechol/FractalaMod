﻿using System;
using FractalaMod.Projectiles; 
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
    public class UpNAtomizer : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("Knock em' up, beat em' down.");
            DisplayName.SetDefault("Up N' Atomizer");
  
        }

        public override void SetDefaults()
        {
            item.damage = 265;
            item.ranged = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 80;
            item.useAnimation = 80;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 60;
            item.value = 10000;
            item.rare = ItemRarityID.Pink;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = ProjectileID.RocketIII;
            item.shootSpeed = 16f;

        }

    }}