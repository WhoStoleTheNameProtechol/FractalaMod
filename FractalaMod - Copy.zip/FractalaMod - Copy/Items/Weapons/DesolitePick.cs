﻿
using FractalaMod.Items.Placeable.Other;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
	public class DesolitePick : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault(" ");
		}

		public override void SetDefaults()
		{

			item.damage = 12;
			item.melee = true;
			item.width = 40;
			item.height = 20;
			item.useTime = 17;
			item.useAnimation = 17;
			item.useStyle = ItemUseStyleID.SwingThrow;
			item.pick = 69;

			item.knockBack = 1;
			item.value = 10000;
			item.rare = ItemRarityID.Blue;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true; //idk why but all the guns in the vanilla source have this


		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemType<DesoliteBar>(), 12);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();

		}
	}
}


