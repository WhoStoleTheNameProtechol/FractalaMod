﻿using System;
using FractalaMod.Projectiles; 
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace FractalaMod.Items.Weapons
{
    public class CopperCan : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("It could at LEAST hurt a fly, not anything stronger though.");
        }

        public override void SetDefaults()
        {
            item.maxStack = 999;
            item.consumable = true;
            item.damage = 10;
            item.ranged = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 15;
            item.useAnimation = 15;
            item.useStyle = ItemUseStyleID.SwingThrow;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 5;
            item.value = 10000;
            item.rare = ItemRarityID.White;
            item.UseSound = SoundID.Item20;
            item.autoReuse = true;
            item.shoot = ProjectileType<Projectiles.CopperCanProjectile>();
            item.shootSpeed = 16f;
            item.noUseGraphic = true;
            item.thrown = true;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CopperBar, 4);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this, 100);
            recipe.AddRecipe();
        }
    }
}