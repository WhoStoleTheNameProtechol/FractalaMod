﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Items.Tools
{
	public class LuminiteRod : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Luminite Rod");
		}
		public override void SetDefaults()
		{
			item.width = 48;
			item.height = 32;
			item.useTime = 8;
			item.useAnimation = 8;
			item.useStyle = ItemUseStyleID.SwingThrow;
			item.value = 100000;
			item.rare = ItemRarityID.LightRed;
			item.UseSound = SoundID.Item1;
			item.autoReuse = false;
			item.shoot = ProjectileID.BobberGolden;
			item.shootSpeed = 18f;
			item.fishingPole = 100;
		}
		public override Vector2? HoldoutOffset()
		{
			return new Vector2(10, 10);






		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.LunarBar, 12);
			recipe.AddIngredient(ItemID.GoldenFishingRod, 1);
			recipe.AddIngredient(ItemID.FiberglassFishingPole, 1);
			recipe.AddIngredient(ItemID.HotlineFishingHook, 1);
			recipe.AddIngredient(ItemID.SittingDucksFishingRod, 1);
			recipe.AddRecipeGroup(RecipeGroupID.IronBar, 1);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}



    
