﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.Items.Tools
{
    public class SuspiciousLookingKnife : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Suspicious Looking Knife");
            Tooltip.SetDefault("Red is ALWAYS the impostor.");
        }

        public override void SetDefaults()
        {
            item.CloneDefaults(ItemID.DD2PetGato);
            item.shoot = mod.ProjectileType("CrewmatePetProjectile");
            item.buffType = mod.BuffType("CrewmateBuff");
        }

        public override void UseStyle(Player player)
        {
            if (player.whoAmI == Main.myPlayer && player.itemTime == 0)
            {
                player.AddBuff(item.buffType, 3600, true);
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup(RecipeGroupID.IronBar, 6);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();

        }
    }
}
             
