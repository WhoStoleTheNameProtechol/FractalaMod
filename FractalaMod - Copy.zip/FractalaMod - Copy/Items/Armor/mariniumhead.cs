using FractalaMod;
using Terraria;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Terraria.ID;

namespace FractalaMod.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class mariniumhead : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("Allows underwater breathing");
            DisplayName.SetDefault("Marinium Helm");
        }

        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.value = 10000;
            item.rare = ItemRarityID.Orange;
            item.defense = 6;
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == ModContent.ItemType<mariniumbody>() && legs.type == ModContent.ItemType<mariniumlegs>();
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Ranged Damage Increased";
            player.AddBuff(BuffID.Gills, 1);
            player.rangedDamage += 0.15f;
            
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod.ItemType("MariniumShard"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}