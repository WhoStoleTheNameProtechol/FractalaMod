using FractalaMod;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;


namespace FractalaMod.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class mariniumlegs : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
            DisplayName.SetDefault("Marinium Greaves");
            Tooltip.SetDefault("Makes you swim like a fish");
        }

        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.value = 120000;
            item.rare = ItemRarityID.Orange;
            item.defense = 6;
        }

        public override void UpdateEquip(Player player)
        {
            player.AddBuff(BuffID.Flipper, 1);
            player.rangedDamage += 0.05f;
            player.moveSpeed += 0.6f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod.ItemType("MariniumShard"), 7);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}