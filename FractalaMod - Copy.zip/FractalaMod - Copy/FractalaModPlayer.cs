﻿using FractalaMod.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;

namespace FractalaMod
{
    public class FractalaModPlayer : ModPlayer
    {
        private bool pet;

        public bool Pet { get => pet; set => pet = value; }

        public bool CrewmatePet;

        public override void ResetEffects()
        {
            CrewmatePet = false;
        }
    }
}
