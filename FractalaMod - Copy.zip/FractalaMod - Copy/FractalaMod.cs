using Terraria.ModLoader;
using FractalaMod;
using FractalaMod.Projectiles;
using FractalaMod.Items.Weapons;
using FractalaMod.Buffs;

namespace FractalaMod
{
	public class FractalaMod : Mod
	{
	}
}