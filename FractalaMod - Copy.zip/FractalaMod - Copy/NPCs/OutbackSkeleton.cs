using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.NPCs
{
	// Party Zombie is a pretty basic clone of a vanilla NPC. To learn how to further adapt vanilla NPC behaviors, see https://github.com/tModLoader/tModLoader/wiki/Advanced-Vanilla-Code-Adaption#example-npc-npc-clone-with-modified-projectile-hoplite
	public class OutbackSkeleton : ModNPC
	{
		public override void SetStaticDefaults() {
			DisplayName.SetDefault("Outback Skeleton");
			Main.npcFrameCount[npc.type] = 19;
		}

		public override void SetDefaults() {
			npc.width = 18;
			npc.height = 40;
			npc.damage = 134;
			npc.defense = 42;
			npc.lifeMax = 340;
			npc.HitSound = SoundID.NPCHit1;
			npc.DeathSound = SoundID.NPCDeath2;
			npc.value = 60f;
			npc.knockBackResist = 0.5f;
			npc.aiStyle = 3;
			aiType = NPCID.BoneThrowingSkeleton;
			animationType = NPCID.BoneThrowingSkeleton;
			banner = Item.NPCtoBanner(NPCID.Skeleton);
			bannerItem = Item.BannerToItem(banner);
			npc.stepSpeed = 36;

		}

		public override float SpawnChance(NPCSpawnInfo spawnInfo) {
			return SpawnCondition.Dungeon.Chance * 0.5f;
		}

		public override void HitEffect(int hitDirection, double damage) {

			}
		}
	}
