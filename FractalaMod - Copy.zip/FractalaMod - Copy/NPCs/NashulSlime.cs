using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace FractalaMod.NPCs
{
	// Party Zombie is a pretty basic clone of a vanilla NPC. To learn how to further adapt vanilla NPC behaviors, see https://github.com/tModLoader/tModLoader/wiki/Advanced-Vanilla-Code-Adaption#example-npc-npc-clone-with-modified-projectile-hoplite
	public class NashulSlime : ModNPC
	{
		public override void SetStaticDefaults() {
			DisplayName.SetDefault("Nashul Slime");
			Main.npcFrameCount[npc.type] = 2;
		}

		public override void SetDefaults() {
			npc.width = 9;
			npc.height = 20;
			npc.damage = 12;
			npc.defense = 2;
			npc.lifeMax = 22;
			npc.HitSound = SoundID.NPCHit1;
			npc.DeathSound = SoundID.NPCDeath2;
			npc.value = 60f;
			npc.knockBackResist = 0.5f;
			npc.aiStyle = 1;
			aiType = NPCID.BlueSlime;
			animationType = NPCID.BlueSlime;
			banner = Item.NPCtoBanner(NPCID.BlueSlime);
			bannerItem = Item.BannerToItem(banner);
			npc.stepSpeed = 36;
		}

		public override float SpawnChance(NPCSpawnInfo spawnInfo) {
			return SpawnCondition.OverworldDaySlime.Chance * 0.3f;
		}

			}
		}

